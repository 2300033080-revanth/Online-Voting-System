package com.auca.VotingApp2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VotingApp2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
