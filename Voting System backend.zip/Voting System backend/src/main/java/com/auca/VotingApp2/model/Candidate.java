package com.auca.VotingApp2.model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Set;

@Data
@Entity
@Table(name = "candidate")
public class Candidate {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long candidateId;
    public String image;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "electionId")
    //@JsonManagedReference
    //@JsonBackReference
    private Election election;

    @OneToMany(mappedBy = "candidate", cascade = CascadeType.ALL)
//    @JsonManagedReference
    private Set<Vote> votes;

    public Candidate() {
    }

	public void setElection(Election election2) {
		// TODO Auto-generated method stub
		
	}

	public Object getFullName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setFullName(Object fullName2) {
		// TODO Auto-generated method stub
		
	}

	public Object getParty() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getImage() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setParty(Object party2) {
		// TODO Auto-generated method stub
		
	}

	public void setImage(Object image2) {
		// TODO Auto-generated method stub
		
	}

	public Object getElection() {
		// TODO Auto-generated method stub
		return null;
	}

	public Long getElectionId() {
		// TODO Auto-generated method stub
		return null;
	}


}
