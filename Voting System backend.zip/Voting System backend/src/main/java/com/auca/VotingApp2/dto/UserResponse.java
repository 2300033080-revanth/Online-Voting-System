package com.auca.VotingApp2.dto;

import org.springframework.web.bind.annotation.RequestMapping;

import lombok.Data;

@Data
public class UserResponse {

 
	public UserResponse(Object id, Object username, RequestMapping requestMapping) {
		// TODO Auto-generated constructor stub
	}

	
}
