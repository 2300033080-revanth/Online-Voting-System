package com.auca.VotingApp2;

public class testCastVote {
}
