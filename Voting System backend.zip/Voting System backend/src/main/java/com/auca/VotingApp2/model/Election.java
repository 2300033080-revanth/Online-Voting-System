package com.auca.VotingApp2.model;


import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

import java.util.List;
@Data
@Entity
@Table(name = "Election")

public class Election {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long electionId;
    private String electionName;
    private String electionDescription;
    private String image;
    private String electionStartDate;
    private String electionEndDate;
    private String electionTime;
    //@JsonIgnore
    @OneToMany(mappedBy = "election", cascade = CascadeType.ALL)

    @JsonBackReference
    //@JsonManagedReference
    private List<Candidate> candidates;

    @OneToMany(mappedBy = "election")
    @JsonIgnore
    private List<Vote> votes;

    public Election() {
    }

	

	public boolean isElectionStatus() {
		// TODO Auto-generated method stub
		return false;
	}



	public String getElectionName() {
		return electionName;
	}



	public void setElectionName(String electionName) {
		this.electionName = electionName;
	}



	public String getElectionDescription() {
		return electionDescription;
	}



	public void setElectionDescription(String electionDescription) {
		this.electionDescription = electionDescription;
	}



	public String getImage() {
		return image;
	}



	public void setImage(String image) {
		this.image = image;
	}



	public String getElectionEndDate() {
		return electionEndDate;
	}



	public void setElectionEndDate(String electionEndDate) {
		this.electionEndDate = electionEndDate;
	}



	public String getElectionStartDate() {
		return electionStartDate;
	}



	public void setElectionStartDate(String electionStartDate) {
		this.electionStartDate = electionStartDate;
	}



	public String getElectionTime() {
		return electionTime;
	}



	public void setElectionTime(String electionTime) {
		this.electionTime = electionTime;
	}



	public void setElectionStatus(boolean electionStatus) {
	}
}
