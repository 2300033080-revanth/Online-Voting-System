package com.auca.VotingApp2.dto;

import lombok.Data;

@Data
public class CandidateDto {
    public long getUserId() {
		// TODO Auto-generated method stub
		return 0;
	}
	public Long getCandidateId() {
		// TODO Auto-generated method stub
		return null;
	}
}
