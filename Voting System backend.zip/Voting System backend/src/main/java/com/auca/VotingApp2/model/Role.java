package com.auca.VotingApp2.model;

public enum Role {
    ROLE_USER,
    ROLE_SELLER,
    ROLE_ADMIN
}