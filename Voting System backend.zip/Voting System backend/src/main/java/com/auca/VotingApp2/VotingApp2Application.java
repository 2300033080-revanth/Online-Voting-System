package com.auca.VotingApp2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VotingApp2Application {

	public static void main(String[] args) {
		SpringApplication.run(VotingApp2Application.class, args);
	}

}


